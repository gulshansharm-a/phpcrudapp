<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<style>
    .pedd{
        margin-left: 50px;  
        margin-right: 50px;  
    }
</style>
</head>
<body>
    <center>
    <h1>Trainers Profiles</h1>
    <a class="btn btn-primary" href="register" >ADD New Profile</a>
  

    </center>



<?php $__currentLoopData = $trainer; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $values): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<br>
<div class="card pedd ">
  <h5 class="card-header"><?php echo e($values['name']); ?>               Id: <?php echo e($values['id']); ?>       </h5>
  <div class="card-body">
    <h5 class="card-title">Email: <?php echo e($values['email']); ?></h5>
    <p class="card-text">Phone: <?php echo e($values['phone']); ?></p>
    <p class="card-text">Experience in years: <?php echo e($values['experience']); ?></p>
    <p class="card-text">City: <?php echo e($values['city']); ?></p>
    <a href="<?php echo e("delete/".$values['id']); ?>" class="btn btn-primary">Delete</a>
    <a href="<?php echo e("edit/".$values['id']); ?>" class="btn btn-primary">Edit</a>
    
  </div>
</div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<br>

  


</body>
</html>

<?php /**PATH C:\xampp\htdocs\crudapp\resources\views/index.blade.php ENDPATH**/ ?>