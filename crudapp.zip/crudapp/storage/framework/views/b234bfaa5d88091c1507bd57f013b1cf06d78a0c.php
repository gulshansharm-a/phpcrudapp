<!DOCTYPE html>  
<html>  
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<style>  
body{  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: ;  
  padding: 400px;  
  padding-top: 0px;
  padding-bottom: 0px;
}  
.container {  
    padding: 50px;  
  background-color: lightblue;  
}  
  
input[type=text], input[type=password], textarea {  
  width: 100%;  
  padding: 15px;  
  margin: 5px 0 22px 0;  
  display: inline-block;  
  border: none;  
  background: #f1f1f1;  
}  
input[type=text]:focus, input[type=password]:focus {  
  background-color: orange;  
  outline: none;  
}  
 div {  
            padding: 10px 0;  
         }  
hr {  
  border: 1px solid #f1f1f1;  
  margin-bottom: 25px;  
}  
.registerbtn {  
  background-color: #4CAF50;  
  color: white;  
  padding: 16px 20px;  
  margin: 8px 0;  
  border: none;  
  cursor: pointer;  
  width: 100%;  
  opacity: 0.9;  
}  
.registerbtn:hover {  
  opacity: 1;  
}  
</style>  
</head>  
<body>  
<form action="/completeedit" method="POST" >  
  <?php echo csrf_field(); ?>
  <div class="container">  
  <center>  <h1> Edit</h1> </center>  
  <hr>  
  <label> Name </label>   
<input type="text" name="name" placeholder= "Name" size="15" value="<?php echo e($data['name']); ?>" required />   

<div>  
<label>   
experience :  
</label>   
<select name="experience"  >
<?php
switch($data['experience']){
case 'null':
   echo  
'<option value="null" selected >experience</option>'.  
'<option value="1">1</option>  '.
'<option value="2">2</option> '. 
'<option value="3">3</option>  '.
'<option value="4">4</option>  '.
'<option value="5">5</option>  '.
'<option value="6">6</option>  '.
'<option value="7">7</option> '.
'<option value="8">8</option>  '.
'<option value="9">9</option> '. 
'<option value="10+"  >10+</option> ';

break;
case '1':
    echo  
 '<option value="null"  >experience</option>'.  
 '<option value="1" selected >1</option>  '.
 '<option value="2">2</option> '. 
 '<option value="3">3</option>  '.
 '<option value="4">4</option>  '.
 '<option value="5">5</option>  '.
 '<option value="6">6</option>  '.
 '<option value="7">7</option> '.
 '<option value="8">8</option>  '.
 '<option value="9">9</option> '. 
 '<option value="10+"  >10+</option> ';
 
 break;
 case '2':
    echo  
 '<option value="null"  >experience</option>'.  
 '<option value="1">1</option>  '.
 '<option value="2" selected >2</option> '. 
 '<option value="3">3</option>  '.
 '<option value="4">4</option>  '.
 '<option value="5">5</option>  '.
 '<option value="6">6</option>  '.
 '<option value="7">7</option> '.
 '<option value="8">8</option>  '.
 '<option value="9">9</option> '. 
 '<option value="10+"  >10+</option> ';
 
 break;
 case '3':
    echo  
 '<option value="null"  >experience</option>'.  
 '<option value="1">1</option>  '.
 '<option value="2">2</option> '. 
 '<option value="3" selected >3</option>  '.
 '<option value="4">4</option>  '.
 '<option value="5">5</option>  '.
 '<option value="6">6</option>  '.
 '<option value="7">7</option> '.
 '<option value="8">8</option>  '.
 '<option value="9">9</option> '. 
 '<option value="10+"  >10+</option> ';
 
 break;
 case '4':
    echo  
 '<option value="null"  >experience</option>'.  
 '<option value="1">1</option>  '.
 '<option value="2">2</option> '. 
 '<option value="3">3</option>  '.
 '<option value="4" selected >4</option>  '.
 '<option value="5">5</option>  '.
 '<option value="6">6</option>  '.
 '<option value="7">7</option> '.
 '<option value="8">8</option>  '.
 '<option value="9">9</option> '. 
 '<option value="10+"  >10+</option> ';
 
 break;
 case '5':
    echo  
 '<option value="null"  >experience</option>'.  
 '<option value="1">1</option>  '.
 '<option value="2">2</option> '. 
 '<option value="3">3</option>  '.
 '<option value="4">4</option>  '.
 '<option value="5" selected >5</option>  '.
 '<option value="6">6</option>  '.
 '<option value="7">7</option> '.
 '<option value="8">8</option>  '.
 '<option value="9">9</option> '. 
 '<option value="10+"  >10+</option> ';
 
 break;
 case '6':
    echo  
 '<option value="null"  >experience</option>'.  
 '<option value="1">1</option>  '.
 '<option value="2">2</option> '. 
 '<option value="3">3</option>  '.
 '<option value="4">4</option>  '.
 '<option value="5">5</option>  '.
 '<option value="6" selected >6</option>  '.
 '<option value="7">7</option> '.
 '<option value="8">8</option>  '.
 '<option value="9">9</option> '. 
 '<option value="10+"  >10+</option> ';
 
 break;
 case '7':
    echo  
 '<option value="null"  >experience</option>'.  
 '<option value="1">1</option>  '.
 '<option value="2">2</option> '. 
 '<option value="3">3</option>  '.
 '<option value="4">4</option>  '.
 '<option value="5">5</option>  '.
 '<option value="6">6</option>  '.
 '<option value="7" selected >7</option> '.
 '<option value="8">8</option>  '.
 '<option value="9">9</option> '. 
 '<option value="10+"  >10+</option> ';
 
 break;
 case '8':
    echo  
 '<option value="null"  >experience</option>'.  
 '<option value="1">1</option>  '.
 '<option value="2">2</option> '. 
 '<option value="3">3</option>  '.
 '<option value="4">4</option>  '.
 '<option value="5">5</option>  '.
 '<option value="6">6</option>  '.
 '<option value="7">7</option> '.
 '<option value="8" selected >8</option>  '.
 '<option value="9">9</option> '. 
 '<option value="10+"  >10+</option> ';
 
 break;
 case '9':
    echo  
 '<option value="null"  >experience</option>'.  
 '<option value="1">1</option>  '.
 '<option value="2">2</option> '. 
 '<option value="3">3</option>  '.
 '<option value="4">4</option>  '.
 '<option value="5">5</option>  '.
 '<option value="6">6</option>  '.
 '<option value="7">7</option> '.
 '<option value="8">8</option>  '.
 '<option value="9" selected >9</option> '. 
 '<option value="10+"  >10+</option> ';
 
 break;
 case '10+':
    echo  
 '<option value="null"  >experience</option>'.  
 '<option value="1">1</option>  '.
 '<option value="2">2</option> '. 
 '<option value="3">3</option>  '.
 '<option value="4">4</option>  '.
 '<option value="5">5</option>  '.
 '<option value="6">6</option>  '.
 '<option value="7">7</option> '.
 '<option value="8">8</option>  '.
 '<option value="9">9</option> '. 
 '<option value="10+" selected >10+</option> ';
 
 break;
 default:
 echo  
 '<option value="null" selected >experience</option>'.  
 '<option value="1">1</option>  '.
 '<option value="2">2</option> '. 
 '<option value="3">3</option>  '.
 '<option value="4">4</option>  '.
 '<option value="5">5</option>  '.
 '<option value="6">6</option>  '.
 '<option value="7">7</option> '.
 '<option value="8">8</option>  '.
 '<option value="9">9</option> '. 
 '<option value="10+"  >10+</option> ';



}


  ?>
</select>
</div>  
<div>  

<label>   
Phone :  
</label>  
<input type="text" name="phone" value="<?php echo e($data['phone']); ?>" placeholder="phone no." size="10"/ required>   
Current City :  
<input type="text" placeholder="Enter Email" value="<?php echo e($data['city']); ?>" name="city" required >  

 <label for="email"><b>Email</b></label>  
 <input type="text" placeholder="Enter Email" value="<?php echo e($data['email']); ?>" name="email" required>  
  <input type="hidden" name="id" value="<?php echo e($data['id']); ?>" >
      
    <button type="submit" class="registerbtn">Edit</button>    
</form>  
</body>  
</html>  <?php /**PATH C:\xampp\htdocs\crudapp\resources\views/edit.blade.php ENDPATH**/ ?>