<?php

namespace App\Http\Controllers;
use App\Models\Trainer;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class maincontroller extends Controller
{ 
    function index(){
        return view('welcome');
    }
    function delete($id){
       $data=Trainer::find($id);
       $data->delete();
       return   redirect('/');
    }
    function edit($id){
        $trainero=Trainer::find($id);
        return view('edit',['data'=>$trainero]);
    }
    function completeedit(Request $req){
        $trainero= Trainer::find($req->id);
        $trainero->name=$req->name;
        $trainero->email=$req->email;
        $trainero->city=$req->city;
        $trainero->experience=$req->experience;
        $trainero->phone=$req->phone;
        $trainero->save();
     return   redirect('/');
    }
    function indexusers(){
        $data=Trainer::all();
        return view('index',['trainer'=>$data]);
    }
    function indexPOST(Request $req){
        $trainero =new Trainer;
        $trainero->name=$req->name;
        $trainero->email=$req->email;
        $trainero->city=$req->city;
        $trainero->experience=$req->experience;
        $trainero->phone=$req->phone;
        $trainero->save();
     return   redirect('/');
    }
    
}
