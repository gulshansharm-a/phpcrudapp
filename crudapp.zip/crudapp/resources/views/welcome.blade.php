<!DOCTYPE html>  
<html>  
<head>  
<meta name="viewport" content="width=device-width, initial-scale=1">  
<style>  
body{  
  font-family: Calibri, Helvetica, sans-serif;  
  background-color: ;  
  padding: 25%;  
  padding-top: 10px;
  padding-bottom: 0px;
}  
.container {  

    padding: 50px;  
  background-color: lightblue;  
}  
  
input[type=text], input[type=password], textarea {  
  width: 100%;  
  padding: 15px;  
  margin: 5px 0 22px 0;  
  display: inline-block;  
  border: none;  
  background: #f1f1f1;  
}  
input[type=text]:focus, input[type=password]:focus {  
  background-color: orange;  
  outline: none;  
}  
 div {  
            padding: 10px 0;  
         }  
hr {  
  border: 1px solid #f1f1f1;  
  margin-bottom: 25px;  
}  
.registerbtn {  
  background-color: #4CAF50;  
  color: white;  
  padding: 16px 20px;  
  margin: 8px 0;  
  border: none;  
  cursor: pointer;  
  width: 100%;  
  opacity: 0.9;  
}  
.registerbtn:hover {  
  opacity: 1;  
}  
</style>  
</head>  
<body>  
<form action="" method="POST" >  
  @csrf
  <div class="container">  
  <center>  <h1> Trainers Registeration Form </h1> </center>  
  <hr>  
  <label> Name </label>   
<input type="text" name="name" placeholder= "Name" size="15" required />   

<div>  
<label>   
experience :  
</label>   
<select name="experience">  
<option value="null">experience</option>  
<option value="1">1</option>  
<option value="2">2</option>  
<option value="3">3</option>  
<option value="4">4</option>  
<option value="5">5</option>  
<option value="6">6</option>  
<option value="7">7</option> 
<option value="8">8</option>  
<option value="9">9</option>  
<option value="10+">10+</option>
</select>  
</div>  
<div>  

<label>   
Phone :  
</label>  
<input type="text" name="phone" placeholder="phone no." size="10"/ required>   
Current City :  
<textarea cols="80" rows="5" name="city"  placeholder="Current Address" value="address" required >  
</textarea>  
 <label for="email"><b>Email</b></label>  
 <input type="text" placeholder="Enter Email" name="email" required>  
  
      
    <button type="submit" class="registerbtn">Register</button>    
</form>  
</body>  
</html>  