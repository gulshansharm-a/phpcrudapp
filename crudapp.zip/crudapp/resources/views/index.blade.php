<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<style>
    .pedd{
        margin-left: 50px;  
        margin-right: 50px;  
    }
</style>
</head>
<body>
    <center>
    <h1>Trainers Profiles</h1>
    <a class="btn btn-primary" href="register" >ADD New Profile</a>
  

    </center>



@foreach($trainer as $values)
<br>
<div class="card pedd ">
  <h5 class="card-header">{{$values['name']}}               Id: {{$values['id']}}       </h5>
  <div class="card-body">
    <h5 class="card-title">Email: {{$values['email']}}</h5>
    <p class="card-text">Phone: {{$values['phone']}}</p>
    <p class="card-text">Experience in years: {{$values['experience']}}</p>
    <p class="card-text">City: {{$values['city']}}</p>
    <a href="{{"delete/".$values['id']}}" class="btn btn-primary">Delete</a>
    <a href="{{"edit/".$values['id']}}" class="btn btn-primary">Edit</a>
    
  </div>
</div>

@endforeach

<br>

  


</body>
</html>

