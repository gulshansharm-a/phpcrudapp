<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\maincontroller;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/register',[maincontroller::class,'index']);
Route::post('/register',[maincontroller::class,'indexPOST']);


Route::get('/',[maincontroller::class,'indexusers']);
Route::get('/edit/{id}',[maincontroller::class,'edit']);
Route::get('/delete/{id}',[maincontroller::class,'delete']);
Route::post('/completeedit',[maincontroller::class,'completeedit']);
